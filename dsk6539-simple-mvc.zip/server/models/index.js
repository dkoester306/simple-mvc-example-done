module.exports.Cat = require('./Cat.js');
module.exports.Dog = require('./Dog.js');

// index.js gets automatically pulled when a folder is required
// We use this to our advantage to define an API for this package.
// We could use it to pull as many files as necessary and send it back as one API
// That way the user only has to implement one require for all
// of the files in this folder we want them to use
